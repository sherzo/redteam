<?php

echo phpinfo();


?>

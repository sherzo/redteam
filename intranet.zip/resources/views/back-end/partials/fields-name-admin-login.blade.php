<h3>{{ Auth::user()->name }}</h3>
<h4>{{ Auth::user()->email }}</h4>
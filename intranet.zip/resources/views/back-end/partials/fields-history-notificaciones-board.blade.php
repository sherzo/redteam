<div class="captionActivitiesRecientes">
    <div class="notficiActivitie">
        <div class="ui relaxed divided list">
            <div class="item PublicatiOn">
                <i class="large github middle aligned icoPubli"></i>
                <div class="content">
                    <a data-href='' href="#!" class="header datanotifiNew"><strong class="nameUserNotifique ">Lisseth </strong> Ha publicado tiene una nueva <span class="typeAccionNotifi">
                  <input type="hidden" class="notifiview" name='datanotifi' value="">
                  <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                  publicación</span></a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoFotos"></i>
                <div class="content">
                    <a data-href='' href="#!" class="header datanotifiNew"><strong class="nameUserNotifique ">Roberto </strong>  ha publicado nuevas <span class="typeAccionNotifi">fotos</span>
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoDocumn"></i>
                <div class="content">
                    <a data-href='' href="#!" class="header datanotifiNew"><strong class="nameUserNotifique ">Juliia </strong>  ha subido un nuevo <span class="typeAccionNotifi">documento</span>
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoUrgente"></i>
                <div class="content">
                    <a data-href='' href="#!" class="header datanotifiNew"><strong class="nameUserNotifique ">Rodolfo </strong>  tiene una publicacion <span class="typeAccionNotifi">urgente</span>
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoCalendar"></i>
                <div class="content">
                    <a data-href='' href="#!" class="header datanotifiNew"><strong class="nameUserNotifique ">Stefany </strong>  agrego un nuevo evento <span class="typeAccionNotifi">al calendario</span>
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoProFile"></i>
                <div class="content">
                    <a data-href="" href="#!" class="header datanotifiNew"><strong class='nameUserNotifique ' >Alejandra </strong>  actualizó su perfil
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoCumple"></i>
                <div class="content">
                    <a  data-href='' href="#!" class="header datanotifiNew"> Hoy es el cumpleaños de <strong class="nameUserNotifique ">Marcela </strong>
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item NewFotos">
                <i class="large github middle aligned icoLikes"></i>
                <div class="content">
                    <a  data-href='' href="#!" class="header datanotifiNew">a 15 personas <span class="typeAccionNotifi ">les gusta tu publicación</span>
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <!-- Notificacion de comentarios -->
            <div class="item NewFotos">
                <i class="large github middle aligned icoComentarios"></i>
                <div class="content">
                    <a  data-href='' href="#!" class="header datanotifiNew"> <span class="typeAccionNotifi">Alex</span> hizo un nuevo comentario
                        <input type="hidden" class="notifiview" name='datanotifi' value="">
                        <input type="hidden" class="notifiviewUser" name='datanotifi_iduser' value="{{  Auth::user()->id }}">
                    </a>
                </div>
            </div>
            <div class="item ActivitiPago">
                <i class="large github middle aligned icoPagos"></i>
                <div class="content">
                    <a class="header">¡Se ha realizado el pago a las 7:00 P.M.!</a>
                </div>
            </div>
        </div>
    </div>
</div>
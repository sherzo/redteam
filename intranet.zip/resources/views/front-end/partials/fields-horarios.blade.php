<div class="col-xs-12 col-sm-12 col-md-12 HorariosUser">
    <div class="col-xs-12 col-sm-12 col-md-12 sectionHorarios">
        <p id='titleHorrarios'>Horarios</p>
        <div class="col-xs-12 col-sm-12 col-md-12 dtsss">
            <p class="ListDays fontMiriamProSemiBold">Lunes,Martes</p>
            <p class="ListHours fontMiriamProRegular">8:00am a 3:00pm</p>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <p class="ListDays fontMiriamProSemiBold">Miercoles, Jueves, Viernes</p>
            <p class="ListHours fontMiriamProRegular">8:00am a 5:00pm</p>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <p class="ListDays fontMiriamProSemiBold">Sabado</p>
            <p class="ListHours fontMiriamProRegular">7:00am a 12:00pm</p>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <p class="ListDays fontMiriamProSemiBold">Días de descanso</p>
            <p class="ListHours fontMiriamProRegular DayDescans">Sabado, Domingo</p>
        </div>
    </div>
</div>
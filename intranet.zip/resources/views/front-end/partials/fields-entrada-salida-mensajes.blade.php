<div class="alert alert-info dataClMoPosPEr dataENtradaMarcada" role="alert">¡Haz marcado tu hora de entrada con exito!</div>
<div class="alert alert-info dataClMoPosPEr dataSalidas" role="alert">¡Haz marcado tu hora de salida con exito!</div>
<div class="alert alert-info dataClMoPosPEr yaMarcado" role="alert">¡Ya haz registrado tu entrada este día!</div>
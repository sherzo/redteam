<div class="col-xs-12 col-sm-12 col-md-12 BuzonSgenerencias DayDisponibles">
    <p>Usted tiene</p>
    <div class="col-xs-12 col-sm-12 col-md-12 sectionSelectDay">
        <div class="col-xs-12 col-sm-6 col-md-6 bgWrapDas dt">
            <p>1</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-6 bgWrapDas dt">
            <p>4</p>
        </div>
    </div>
    <p>de vacaciones pendientes</p>
</div>
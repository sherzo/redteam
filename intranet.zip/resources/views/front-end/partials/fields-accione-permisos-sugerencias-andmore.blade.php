<div class="col-xs-12 col-sm-12 col-md-12 BuzonSgenerencias">
    <a href="buzon-sugerencias">
        <p>Buzón de sugerencias</p>
    </a>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 BuzonSgenerencias">
    <a href="emergencia">
        <p>Emergenica/ imprevisto</p>
    </a>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 BuzonSgenerencias">
    <a href="solicitud-permiso">
        <p>Solicitar permisos</p>
    </a>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 LinksForEmpleados">
    <ul>
        <li>
            <a href="{{ asset('assets/pdf/Manual-de-empleado.pdf') }}" target="_blank">
                Manual de empleado
            </a>
        </li>
        <li>
            <a href="">
                Reglamento institucional
            </a>
        </li>
        <li>
            <a href="">
                Ayuda
            </a>
        </li>
    </ul>
</div>

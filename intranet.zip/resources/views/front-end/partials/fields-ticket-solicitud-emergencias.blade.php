<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 permission">
    <h3>Solicitudes de Emergencias</h3>

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 contectAllMenssages">
        <div class="col-xs-12 col-sm-11 col-md-11 col-lg-11 textAllsMensages">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fchaUisersMensage">
                <p>16 abril 2018</p>
            </div>
            <div class="col-xs-12 col-sm-2 col-md-1 col-lg-1 secFotoUser" style="background-image: url('{{ asset('assets/profiles/49907.png') }}')">
            </div>
            <div class="col-xs-12 col-sm-7 col-md-11 col-lg-11 sectioForMEnsagen secdataTextMensage">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 nameUisersMensage">
                    <h3 class="vieCandidate">Lisset Rivas </h3>
                    <h3>Lisset Rivas </h3>

                    <img class="img-responsive" src="{{ asset('assets/images/avatar/adjuntarFoto.png') }}" alt="" data-toggle="modal" data-target="#myModalswAdjunImg"></h3>

                    <div class="modal fade" id="myModalswAdjunImg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog dialoDataImgen" role="document">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <img class="img-responsive" src="{{ asset('assets/images/documents/46206.docx') }}" alt="">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <img class="img-responsive" src="{{ asset('assets/images/avatar/adjuntarIco.png') }}" alt=""></h3>

                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 typeUisersMensage">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 createMotive">
                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 motivePermiso">
                            <span> Motivo de permiso: </span>
                        </div>
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 descriptMotivo">
                            <p>Necesito ir a cuidar a madre</p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 createMotive">
                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 motivePermiso">
                            <span> Fechas: </span>
                        </div>
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 descriptMotivo">
                            <p>15 marzo 2017 </p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 createMotive">
                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 motivePermiso">
                            <span> Descuento en: </span>
                        </div>
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 descriptMotivo">
                            <p>Día de Vacación </p>
                            <p>Día Septimo</p>
                            <p>Sin descuento</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="dataClicDEsplace deplaceDatSolictudes col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="ui accordion">
                <div class="title">
                    <i class="fa fa-angle-down " aria-hidden="true" data-idsolicitud=""></i>
                </div>
                <div class="content conFormularioReturnMenSage">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 captionCOmetsReceibe captionComenSolicitud">
                        <div class="col-xs-12 col-sm-4 col-md-1 col-lg-1 captionCOmetsReceibeIMgUser">
                            <div class="col-xs-12 col-sm-2 col-md-1 col-lg-1 secFotoUser" style="background-image: url('{{ asset('assets/profiles/49907.png') }}')">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-8 col-md-11 col-lg-11 captionCOmetsReceibeDescriUserCOmen">
                            <h4>Jolieette rivas
                                <img class="img-responsive" src="{{ asset('assets/images/avatar/adjuntarIco.png') }}" alt="" data-toggle="modal" data-target="#myModalswAdjunImgComen1"></h3>
                                <div class="modal fade" id="myModalswAdjunImgComen2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog dialoDataImgen" role="document">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <img class="img-responsive" src="{{ asset('assets/images/documents/65302.jpg') }}" alt="">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </h4>
                            <p>EMergencia general</p>
                        </div>
                    </div>
                    <p>Responder</p>
                    <div href="#!" class="clActiveMOdalS" data-toggle="modal" data-target="#myModalSolicitudRespuesta" style="display:none;"></div>
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 formsActions">
                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 Sendmensage">
                            <div class="panel-group" id="accordionq" role="tablist" aria-multiselectable="true">
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title">
                                            <a class="collapsed collapseDataPermisos" role="button" data-toggle="collapse" data-parent="#accordionq" href="#collapseTwoEmer" aria-expanded="false" aria-controls="collapseTwoEmer">
                                                Enviar mensaje
                                            </a>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="" class="formReturnMennsage conteFormSolicitru" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 textAreaReturn">
                                <textarea name="descrip_comen_suge"></textarea>
                            </div>
                            <div class="contenMoreDocuments">
                                <input type="file" class="fileInputAdmin" name="fileinputdocuemnt" />
                            </div>

                            <div class="contenMoreImages">
                                <input type="file" class="fileInputAdminImage" name="fileinputimage" />
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 submitSendSugerencia">
                                <input type="submit" value="Enviar">
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 bloqueImageretu">
                                <img class="img-responsive imImga" onclick="chooseFileImageSuAd();" src="{{ asset('assets/images/avatar/adjuntarFoto.png') }}" alt="">
                                <img class="img-responsive img1Do" onclick="chooseFileDocuSuAd()" src="{{ asset('assets/images/avatar/adjuntarIco.png') }}" alt="">
                            </div>
                        </div>
                        <input type="hidden" name="id_user_sugerencia" value="">
                        <input type="hidden" name="id_solicitudse" value="">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('content'); ?>        
    
    <?php echo $__env->make('components.header-admin', [
        'title' => 'Usuarios',
        'placeholder' => 'Buscar usuarios por su nombre'
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- SECTION MENU INTERNO HOME -->
    <section class="container-fluid">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 sectionMenuInterno">
            <ul class="listActionDocuemntps">
                <li ><a href="<?php echo e(url('admin/home')); ?>">Home</a></li>
                <li><a href="board">Board</a></li>
                <li class="active"><a href="usuarios">Usuarios</a></li>
                <li class="dreopDocument">
                    <div class="dropdown dwropOptionMensgae">
                        <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dLabel">
                            <li class="selecEdit">
                                <a href="#!">Seleccionar y editar</a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="GetGroup">
                    <form action="usuarios/grupos/edit" method="post" accept-charset="utf-8" class="formSelectGropu">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" value="Editar usuarios seleccionados">
                    </form>
                </li>
            </ul>
        </div>
    </section>


    <!-- SECTION BLOQUE NOTIFICACION Y MENSAJES -->
    <section class="container-fluid sectionAdminNotifiMensa">
        <div class="col-md-12">
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 sectionCenterContenido centerContentAllUSer">
                    
                <?php echo $__env->make('back-end.users.partials.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 actionAllUsers">
                <a href="<?php echo e(route('users.create')); ?>">
                    <p>
                        Nuevo usuario
                    </p>
                </a>

            </div>
            
            <div class="col-md-12 datPublich publishChatAdmin publichDocuemnts">
                <img class="img-responsive" src="<?php echo e(asset('assets/images/avatar/addpubliImgae.png')); ?>" alt="" data-toggle="modal" data-target="#myModal">
                <img class="img-responsive" src="<?php echo e(asset('assets/images/avatar/AnuncioPublicAdmin.png')); ?>" alt=""  data-toggle="modal" data-target="#myModalNotifications">
            </div>
        </div>
    </section>


    <!-- Modal -->
    <?php echo $__env->make('front-end.partials.field-public-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Modal NOTIFICACIONES -->
    <?php echo $__env->make('back-end.partials.fields-modal-notificaciones', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div class="alert alert-info dataClMoPosPEr" role="alert">¡Publicacion Agregada!</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
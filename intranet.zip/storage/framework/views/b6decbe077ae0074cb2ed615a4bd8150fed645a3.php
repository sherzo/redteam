<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet">
    <!-- Style Menu Desplace  -->
    <link href="<?php echo e(asset('assets/css/menu/component.css')); ?>" rel="stylesheet">
    <!-- Semantic Ui CSS -->
    <link href="<?php echo e(asset('assets/css/semantic.css')); ?>" rel="stylesheet">
    <!-- STYLE FONT AWESOME -->
    <link href="<?php echo e(asset('assets/css/font-awesome.css')); ?>" rel="stylesheet">
    <!-- Datepicker Files -->
    <link href="<?php echo e(asset('assets/css/datePicker/bootstrap-datepicker3.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
    <!-- ClockPicker -->
    <link href="<?php echo e(asset('assets/css/clock/bootstrap-clockpicker.min.css')); ?>" rel="stylesheet">
    <!-- ColorPicker -->
    <link href="<?php echo e(asset('assets/css/admin/colorpicker/spectrum.css')); ?>" rel="stylesheet">
    <!-- Main style -->
    <link href="<?php echo e(asset('assets/css/admin/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/admin/main_responsive.css')); ?>" rel="stylesheet">
    
   
   <link href="http://hayageek.github.io/jQuery-Upload-File/4.0.10/uploadfile.css" rel="stylesheet"> 
   <?php echo $__env->yieldContent('css'); ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body class="bgUser">

    <div id="app">
        <nav class="navbar navbar-default navbar-static-top navbarHome bgAdmins">
            <div class="container">
                <div class="navbar-header">
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>

                
                <div class="collapse navbar-collapse collapseMenuUser menuAdmin" 
                id="app-navbar-collapse">
                    
                    <?php echo $__env->make('back-end.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   
                </div>
                 
            </div>
        </nav>
    
        
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script type="text/javascript">
        $('#myModalSolicitudRespuestCorrect').modal('show');
    </script>
    <script src="<?php echo e(asset('assets/js/menu/classie.js')); ?>" type="text/javascript" ></script>
    <script src="<?php echo e(asset('assets/js/menu/gnmenu.js')); ?>" type="text/javascript" ></script>
    <script src="<?php echo e(asset('assets/js/semantic.js')); ?>" type="text/javascript" ></script>
    <script>
        $('.dropdownSemantic')
            .dropdown({
                transition: 'drop'
            });

    </script>
    <script>
        $('.button')
            .popup({
                inline: true
            });
        $('.dropdownSemantic')
            .dropdown({
                transition: 'drop'
            });
        $('.accordion')
            .accordion({
                selector: {
                    trigger: '.title div .fa-angle-down'
                }
            })
        ;

        $('.max.example .ui.fluid.dropdown')
            .dropdown({
                maxSelections: 15
            })
        ;
        $('.dataClicDEsplace .accordion')
            .accordion({
                selector: {
                    trigger: '.title .fa-angle-down'
                }
            })
        ;
        $('.rating')
            .rating({
                maxRating: 5,
                disable: false,
            });
        $('.rating')
            .rating('disable')
        ;

        $('.bloqueActionAddNodui .accordion')
            .accordion({
                selector: {
                    trigger: '.title'
                }
            })
        ;

    </script>
    
    <script src="<?php echo e(asset('assets/js/moment.js')); ?>" type="text/javascript" ></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>" type="text/javascript" ></script>
    <script type="text/javascript">
        $(function () {
            $('#datetimepicker12').datetimepicker({
                inline: true,
                sideBySide: true
            });
        });
    </script>
    
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript">
        $('div.alert').not('.alert-important').delay(3000).fadeOut(350);
        //<![CDATA[
        $(window).load(function(){
            $(".togleAdmin").click(function() {
                $('#sidebar3').toggleClass('sidebar3Hiden');
                var toggle_el = $(this).data("toggle");
                $(toggle_el).toggleClass("open-sidebar");
                // $('.container.continerWithSite').toggleClass("widthFull");
            });
        });//]]>

    </script>
    <script src="<?php echo e(asset('assets/js/admin/main.js')); ?>" type="text/javascript" ></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>

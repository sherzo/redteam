<h3><?php echo e(Auth::user()->name); ?></h3>
<h4><?php echo e(Auth::user()->email); ?></h4>
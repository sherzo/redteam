<?php $__env->startSection('content'); ?>
    <div class="container continerWithSite containBloquePro">
        <div class="row">            
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 captionPosteos captionProfiles">

                <!-- CAPTION USER LIVES -->
            <?php echo $__env->make('front-end.partials.fields-users-all-chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- SOLICITUD EN PROCESO -->
            <?php echo $__env->make('front-end.partials.fields-solicitud-proceso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- HORARRIOS DE USURIOS -->
            <?php echo $__env->make('front-end.partials.fields-horarios', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- BUZON DE SUGERENCIAS , EMERGENCIAS Y SOLICITUDES -->
            <?php echo $__env->make('front-end.partials.fields-accione-permisos-sugerencias-andmore', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Dias disponibles -->
            <?php echo $__env->make('front-end.partials.fields-day-vacaciones-users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Manuales -->
                <?php echo $__env->make('front-end.partials.fields-manuales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 sectionProfiles">
            <?php echo e(Form::open(['route' => 'profile.update', 'id' => 'formprofile', 'files' => true])); ?>


                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ProfileFotosStarts">
                    <div class="containerPhotoProfile" style="background-image: url()">
                        <img src="<?php echo e($user->avatar); ?>" alt="" class="containerPhotoProfile" id="imgPhoto" onclick="activateInput()">
                        <input type="file" style="display: none;" onchange="readURL(this)" id="inputPhoto" name="avatar" disabled="" class="dtaYesEdit">
                    </div>
                    <p class="colorBlack fontMiriamProSemiBold"><?php echo e($user->full_name); ?></p>
                    <div class="ui star rating" data-rating="5"></div>
                </div>
                <!-- Information empleado -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 InformacionEmpleado">
                    <form action="profile_submit" method="get" class="profile_userEdit" accept-charset="utf-8">
                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataEmpleados">

                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 ColumnsData">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Departamento</p>
                                    <select name="area_id" class="detallInformation dtaYesEdit" disabled="">
                                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php echo e($user->work->area_id == $key ? 'selected' : ''); ?>><?php echo e($area); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Cargo</p>
                                    <input class="detallInformation" type="text" value="<?php echo e($user->work->position); ?>" disabled="disabled">
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Jefe inmediato</p>
                                    <input class="detallInformation" type="text" name="" value="<?php echo e($user->boss_name); ?>" disabled="disabled">

                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">ADP</p>
                                    <input class="detallInformation" type="text" value="Ninguno" disabled="disabled">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 ColumnsData">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Género</p>
                                    <select name="gender" disabled="" class="detallInformation dtaYesEdit">
                                        <option value="1" <?php echo e($user->gender == 1 ? 'selected' : ''); ?> >Masculino</option>
                                        <option value="0"  <?php echo e($user->gender == 0 ? 'selected' : ''); ?> >Femenino</option>
                                    </select>
                                    
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Estado Civil</p>
                                    <select name="marital" class="detallInformation dtaYesEdit" disabled="">
                                    <option value="0" <?php echo e($user->personal->marital == 0 ? 'selected' : ''); ?>>Soltero/a</option>
                                    <option value="1" <?php echo e($user->personal->marital == 1 ? 'selected' : ''); ?>>Casado/a</option>
                                    <option value="2" <?php echo e($user->personal->marital == 2 ? 'selected' : ''); ?>>Divorciado/a</option>
                                    <option value="3" <?php echo e($user->personal->marital == 3 ? 'selected' : ''); ?>>Viudo/a</option>
                                </select>
                                    
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Dirección</p>
                                    <input class="detallInformation dtaYesEdit" name="address" type="text" value="<?php echo e($user->personal->address); ?>" disabled="disabled">
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Correo</p>
                                    <input class="detallInformation dtaYesEdit" name="personal_email" type="email" value="<?php echo e($user->personal->personal_email); ?>" disabled="disabled">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 ColumnsData">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Cumpleaños</p>
                                    <input class="detallInformation dtaYesEdit" name="birthdate" type="date" value="<?php echo e($user->personal->birthdate); ?>" disabled="disabled">
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Número de celular</p>
                                    <input class="detallInformation dtaYesEdit" name="phone" type="text" value="<?php echo e($user->work->phone); ?>" disabled="disabled">
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Extención</p>
                                    <input class="detallInformation dtaYesEdit" name="extension" type="text" value="<?php echo e($user->work->extension); ?>" disabled="disabled">
                                </div>

                            </div>

                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataEmpleados TwoSection">
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 ColumnsData">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Técnico</p>
                                    <input class="detallInformation dtaYesEdit" name="technical" type="text" value="<?php echo e($user->academic->technical); ?>" disabled="disabled">
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Posgrado</p>
                                    <input class="detallInformation dtaYesEdit" name="postgraduate" type="text" value="<?php echo e($user->academic->postgraduate); ?>" disabled="disabled">
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Diplomado</p>
                                    <input class="detallInformation dtaYesEdit" name="diplomat" type="text" value="<?php echo e($user->academic->diplomat); ?>" disabled="disabled">
                                </div>

                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 ColumnsData">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Habilidades</p>
                                    <input class="detallInformation dtaYesEdit" name="abilities" type="text" value="<?php echo e($user->academic->abilities); ?>" disabled="disabled">
                                </div>

                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 ColumnsData">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ColumnsDataText">
                                    <p class="titleInformation">Otros conocimientos</p>
                                    <input class="detallInformation dtaYesEdit" name="others" type="text" value="<?php echo e($user->academic->others); ?>" disabled="disabled">
                                </div>

                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 DataEditar dataeditarProfile">
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->id == $user->id): ?>
                                        <a href="#!" class="activeEditar">
                                            <p>Editar</p>
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>  

                                <a href="#" class="dataSaveChanges" >
                                    <p>Guardar</p>
                                </a>
                            </div>

                        </div>
                    </form>

                </div>

            <?php echo e(Form::close()); ?>



                <!-- EVENTOS COMPARTIDOS -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataEventos">
                    <h3>Eventos compartidos</h3>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-7 col-lg-7 captionPosteos captionPostesOfUser">
                    

                    <!-- BLOQUE LATERAL  -->
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                        <div class="col-md-12">
                            <div class="ui feed uifeedAvatar">
                                <div class="event">
                                    <div class="label dataPrubeIm" style="background-image: url('<?php echo e(asset('assets/profiles/49907.png')); ?>')">
                                    </div>
                                    <div class="content">
                                        <div class="summary">
                                            <a class="user colorGrisMediumSuave fontMiriamProSemiBold">
                                                Leonardo
                                            </a>
                                            <div class="date fontMiriamProRegular colorGrisMediumSuave">
                                                1 Hour
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p class="textCOment fontMiriamProRegular colorGrisMediumSuave">Awww que bonito loremp imsum loremp imsum loremp imsum loremp imsum</p>
                            <div class="ui feed uifeedActions">
                                <div class="event">
                                    <div class="label">
                                        <img class="img-responsive" src="<?php echo e(asset('assets/images/etiqueta-ico.png')); ?>">
                                    </div>
                                    <div class="content contLike">
                                        <div class="summary">
                                            <a class="user colorGrisMediumSuave fontMiriamProSemiBold">
                                                45 Likes
                                            </a>
                                            <div class="date datePint fontMiriamProRegular colorGrisMediumSuave">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/images/pines-ico.png')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="ui feed uifeedComnetUser">
                                <div class="event">
                                    <div class="label dataPrubeIm" style="background-image: url('<?php echo e(asset('assets/profiles/49907.png')); ?>')">
                                    </div>
                                    <div class="content">
                                        <div class="summary">
                                            <a class="user colorGrisMediumSuave fontMiriamProSemiBold">
                                                Leonardo
                                            </a>
                                            <div class="date fontMiriamProRegular colorGrisMediumSuave comentUser">
                                                Awww que bonito
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <form class="ui form formComentUser">
                                <div class="field">
                                    <textarea name="comentario_post"  placeholder="Comentario" required></textarea>
                                    <input type="hidden" class="iduserComent" name="coment_action_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" class="idDataPost" name="data_id_post" value="">
                                </div>
                                <a href="" class="dataComenyt"><p>Comentar</p></a>
                            </form>
                        </div>
                    </div>
                </div>
            

            </div>

            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 captionRecordNotas SecCalendar">

                <!-- BLOQUE CALENDAR -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                    <!-- SECTION CALENDAR AND ADD EVENT CALENDAR -->
                <?php echo $__env->make('front-end.partials.fields-lateral-calendar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- GALERIA DE FOTOS -->
                    <?php echo $__env->make('front-end.partials.fields-galeria-fotos-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                </div>

            </div>
        </div>

        <div class="col-md-12 datPublich">
            <img class="img-responsive" src="<?php echo e(asset('assets/images/avatar/IcoPublich.png')); ?>" alt="" data-toggle="modal" data-target="#myModal">
        </div>

    </div>

    <?php echo $__env->make('front-end.partials.field-public-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="alert alert-info dataClMoPosPEr" role="alert">¡Publicacion Agregada!</div>
    <!-- Mensajes entrada salida -->
    <?php echo $__env->make('front-end.partials.fields-entrada-salida-mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('front-end.partials.fields-windows-chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    $('.dataeditarProfile').click(function(event) {
        $('.dtaYesEdit').prop( "disabled", false );
        $('.dtaYesEdit').toggleClass("profileEidtars");
        $('.dataSaveChanges').addClass('dataSaveChangesActive');
        $('.activeEditar').addClass('disabelBOtEdit');
    });

    $('.dataSaveChanges').click(function(e){
        e.preventDefault();
        $('#formprofile').submit();
    })
});
</script>
<script src="<?php echo e(asset('assets/js/src/upload-file.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Template-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
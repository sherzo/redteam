 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 bloqueUsersAll">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 allDatasUserTitles">
        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 ">
            <p>Todos los contatos <span>(<?php echo e($users->count()); ?>)</span> </p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
            <p>Correo</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1">
            <p>Celular</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1">
            <p>Ext.</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-2 col-lg-2">
            <p>Ranking</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1">
            <p>ADP</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1">
            <p>Nota</p>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataAllUserSer">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 allDatasUser">
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 imgAndNameUser">
                <div class="dropdown DropOptinUsersD optionAllUsers">
                    <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dLabel">
                        <li>
                            <a href="<?php echo e(route('users.edit', $user->id)); ?>">Editar información</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('users.schedule', $user->id)); ?>">Editar horario</a>
                        </li>
                        <li>
                            <?php echo e(Form::open(['route' => ['users.destroy', $user->id], 'method' => 'DELETE'])); ?>

                                <input type="submit" value="Eliminar">
                            <?php echo e(Form::close()); ?>

                        </li>
                    </ul>
                </div>

                <input type="checkbox" class="datSelectEdit" value="3">
                <a href="<?php echo e(url('profile', $user->username)); ?>">
                    <div class="label dataPrubeIm dataProfileAllUsers" style="background-image: url('<?php echo e($user->avatar); ?>')"></div>
                    
                </a>
                <p class="fontMiriamProSemiBold"><?php echo e($user->full_name); ?></p>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 EmailUser topDatasUser">
                <p><?php echo e($user->email); ?></p>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1 CelUsers topDatasUser">
                <p><?php echo e($user->work->phone); ?></p>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1 ExtUsers topDatasUser">
                <p><?php echo e($user->work->extension); ?></p>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-2 col-lg-2 RankinUsers topDatasUser">
                <div class="ui star rating disabled" data-rating="5"><i class="icon active"></i><i class="icon active"></i><i class="icon active"></i><i class="icon active"></i><i class="icon active"></i></div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1 AdpUsers topDatasUser">
                <p class="gasper">0</p>
                <p class="gasper">1</p>
                <p>0</p>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-1 col-lg-1 NotUses topDatasUser">
                <p class="gasper"> 0</p>
                <p>0</p>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataAllUserSer">
            <h5>No se encontraron resultados</h5>
        </div>
    <?php endif; ?>
</div>
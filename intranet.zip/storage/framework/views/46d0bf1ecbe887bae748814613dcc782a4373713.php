<?php $__env->startSection('content'); ?>
    <div class="container continerWithSite">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 captionPosteos captionProfiles">

                <!-- CAPTION USER LIVES -->
            <?php echo $__env->make('front-end.partials.fields-users-all-chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- SOLICITUD EN PROCESO -->
            <?php echo $__env->make('front-end.partials.fields-solicitud-proceso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- HORARRIOS DE USURIOS -->
            <?php echo $__env->make('front-end.partials.fields-horarios', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- BUZON DE SUGERENCIAS , EMERGENCIAS Y SOLICITUDES -->
            <?php echo $__env->make('front-end.partials.fields-accione-permisos-sugerencias-andmore', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Dias disponibles -->
            <?php echo $__env->make('front-end.partials.fields-day-vacaciones-users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Manuales -->
                <?php echo $__env->make('front-end.partials.fields-manuales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            </div>

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 sectionProfiles sectionPermissionRequest">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 remenber">
                    <h3>¡Detalles de tu procesos de solicitudes!</h3>
                </div>
                <p class="alert alert-success">Tu comentario fue publicado con exito</p>

                
                <?php echo $__env->make('front-end.partials.fields-ticket-solicitud-permiso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                
                <?php echo $__env->make('front-end.partials.fields-ticket-solicitud-emergencias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                
                <?php echo $__env->make('front-end.partials.fields-ticket-solicitud-sugerencias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 captionRecordNotas SecCalendar">

                <!-- BLOQUE CALENDAR -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <!-- SECTION CALENDAR AND ADD EVENT CALENDAR -->
                <?php echo $__env->make('front-end.partials.fields-lateral-calendar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- GALERIA DE FOTOS -->
                    <?php echo $__env->make('front-end.partials.fields-galeria-fotos-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>

        <div class="col-md-12 datPublich">
            <img class="img-responsive" src="<?php echo e(asset('assets/images/avatar/IcoPublich.png')); ?>" alt="" data-toggle="modal" data-target="#myModal">
        </div>

    </div>

    <!-- Modal -->
    <?php echo $__env->make('front-end.partials.field-public-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="alert alert-info dataClMoPosPEr" role="alert">¡Publicacion Agregada!</div>

    <!-- Mensajes entrada salida -->
    <?php echo $__env->make('front-end.partials.fields-entrada-salida-mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('front-end.partials.fields-windows-chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Template-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
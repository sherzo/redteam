<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('components.header-admin', [
        'title' => 'Editar usuarios',
        'placeholder' => 'Buscar por nombre de usuario'
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- SECTION BLOQUE NOTIFICACION Y MENSAJES -->
    <section class="container-fluid sectionAdminNotifiMensa">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 OtherUserEdit">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataForUserdonw">

                        <div class="label dataPrubeIm dataProfileEditUsersAlls" style="background-image: url(<?php echo e($usr->avatar); ?>)"></div>
                        <a href="<?php echo e(route('users.edit', $usr->id)); ?>">
                            <p class="fontMiriamProSemiBold"><?php echo e($usr->full_name); ?></p>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
            </div>

            <?php echo e(Form::model($user, ['route' => ['users.update', $user->id], 'method' => 'PUT', 'files' => true])); ?>

            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 sectionCenterContenido sectionCenEdituser">
                
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataBloquesForEdit">
                        <h3 class="editAs">Editar a <?php echo e($user->full_name); ?></h3>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 dataImgAndranking">
                            <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 imgProfiEdit">
                                <div class="label dataPrubeIm dataProfileEditUsers" style="background-image: url('<?php echo e($user->avatar); ?>')"></div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-5 col-lg-5 editRankinFoto">
                                <h3><?php echo e($user->name); ?></h3>
                                <div class="contEditDatRanking">
                                    <div class="ui star rating disabled" data-rating="4"><i class="icon active"></i><i class="icon active"></i><i class="icon active"></i><i class="icon active"></i><i class="icon"></i></div>
                                </div>
                                <a href="#!" id="fileuploader">
                                    <div class="ajax-upload-dragdrop" style="vertical-align: top; width: 400px;">
                                        <div class="ajax-file-upload" style="position: relative; overflow: hidden; cursor: default;">Upload
                                        
                                            <input type="file" id="ajax-upload-id-1523511476755" name="avatar" style="position: absolute; cursor: pointer; top: 0px; width: 100%; height: 100%; left: 0px; z-index: 100; opacity: 0;">
                                        
                                        </div>
                                        <span style="display: none;"><b>Drag &amp; Drop Files</b>
                                     
                                        </span>
                                    </div>
                                <div></div>
                                </a><div class="ajax-file-upload-container"></div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 DataformPersonales">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Departamento al que pertenece</label>
                                <select name="area_id">
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($user->work->area_id == $key ? 'selected' : ''); ?>><?php echo e($area); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Cargo</label>
                                <input type="text" name="position" value="<?php echo e($user->work->position); ?>">
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Jefe Inmediato</label>
                                <select name="boss_id" required="">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($boss->id); ?>" <?php echo e($user->boss_id == $boss->id ? 'selected' : ''); ?>>
                                            <?php echo e($boss->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 DataformPersonales dataInformationPersonal">
                            <h3>Información personal</h3>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Género</label>
                                <select name="data_genero_edit" value="Masculino">
                                    <option value="1" <?php echo e($user->gender == 1 ? 'selected' : ''); ?> >Masculino</option>
                                    <option value="0"  <?php echo e($user->gender == 0 ? 'selected' : ''); ?> >Femenino</option>
                                </select>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Estado civil</label>
                                <select name="marital" required>
                                    <option value="0" <?php echo e($user->personal->marital == 0 ? 'selected' : ''); ?>>Soltero/a</option>
                                    <option value="1" <?php echo e($user->personal->marital == 1 ? 'selected' : ''); ?>>Casado/a</option>
                                    <option value="2" <?php echo e($user->personal->marital == 2 ? 'selected' : ''); ?>>Divorciado/a</option>
                                    <option value="3" <?php echo e($user->personal->marital == 3 ? 'selected' : ''); ?>>Viudo/a</option>
                                </select>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Cumpleaños</label>
                                <input type="date" name="birthdate" value="<?php echo e($user->personal->birthdate); ?>">
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Correo</label>
                                <input type="email" name="personal_email" value="<?php echo e($user->personal->personal_email); ?>">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps inputSaDbdi">
                                    <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 datTwoBliuqye">
                                        <label for="">Celular</label>
                                        <input type="text" name="phone" value="<?php echo e($user->work->phone); ?>">
                                    </div>
                                    <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 datTwoBliuqye inputEditDatps">
                                        <label for="">Extención</label>
                                        <input type="text" name="extension" value="<?php echo e($user->work->extension); ?>" required="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formInputsDats inputEditDatps">
                                <label for="">Dirección</label>
                                <input type="text" name="address" value="<?php echo e($user->personal->address); ?>" required="">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 databLoquOclock">
                        <h3>Horario</h3>
                        <h4>Días completos</h4>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 databLoquOclockDetallDiasCompleto dayCOmpleTop">
                            <?php $__currentLoopData = $completes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 bloqueHorarioCompletos bloOONes block<?php echo e($k+1); ?>Edit">
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 daataEntrada">
                                    <div class="form-group">
                                        <h4>Entrada</h4>
                                        <div class="clearfix">
                                            <div class="input-group clockpicker pull-center" data-placement="left" data-align="top" data-autoclose="true">
                                                <input type="text" class="form-control" value="<?php echo e($complete->entry); ?>">
                                                <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-time"></span>
                                        </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 daataSalida">
                                    <div class="form-group">
                                        <h4>Salida</h4>
                                        <div class="clearfix">
                                            <div class="input-group clockpicker pull-center" data-placement="left" data-align="top" data-autoclose="true">
                                                <input type="text" class="form-control" value="<?php echo e($complete->exit); ?>">
                                                <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-time"></span>
                                        </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <p class="mnsAlertVacio">Debes seleccionar hora de entrada y salida</p>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 DaysOfSelect">
                                    <div class="form-group formSelectDays formseledDiasCOmple">
                                        <p class="gasper">2</p>
                                        <h4 class="repetah4">Repetir</h4>
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12  bloqueDayss">
                                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <div class="DayForDayEdit domin 
                                                    <?php $__currentLoopData = $complete->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($d->day == $key): ?>    
                                                            DaySelectActiveEdit
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    " data-time="" data-day="<?php echo e($daysShow[$key]); ?>">
                                                    <?php echo e($day); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <h4>Medio día</h4>
                        <?php $__currentLoopData = $midday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $mid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 databLoquOclockDetallMedioDia">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 bloqueHorarioCompletos blockMedio<?php echo e($k+1); ?>Edit">
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 daataEntrada">
                                    <div class="form-group">
                                        <h4>Entrada</h4>
                                        <div class="clearfix">
                                            <div class="input-group clockpicker pull-center" data-placement="left" data-align="top" data-autoclose="true">
                                                <input type="text" class="form-control" value="<?php echo e($mid->entry); ?>">
                                                <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-time"></span>
                                        </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 daataSalida">
                                    <div class="form-group">
                                        <h4>Salida</h4>
                                        <div class="clearfix">
                                            <div class="input-group clockpicker pull-center" data-placement="left" data-align="top" data-autoclose="true">
                                                <input type="text" class="form-control" value="<?php echo e($mid->exit); ?>">
                                                <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-time"></span>
                                        </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <p class="mnsAlertVacio">Debes seleccionar hora de entrada y salida</p>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 DaysOfSelect">
                                    <div class="form-group formSelectDays formseledDiasCOmple">
                                        <p class="gasper">2</p>
                                        <h4 class="repetah4">Repetir</h4>
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12  bloqueDayss">
                                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <div class="DayForDayEdit domin 
                                                    <?php $__currentLoopData = $mid->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($d->day == $key): ?>    
                                                            DaySelectActiveEdit
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    " data-time="" data-day="<?php echo e($daysShow[$key]); ?>">
                                                    <?php echo e($day); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 bloqueAddHorarios">
                            <?php $__currentLoopData = $completes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $dayss = '';
                                    foreach($complete->days as $ke => $day){
                                    echo $dayss;
                                       $dayss .= $daysShow[$day->day];
                                       if($ke < ($mid->days->count()-1)) {
                                        $dayss .= ',';
                                       }
                                    }                                    
                                ?>
                                <input type="hidden" class="repeatBloqOneEdit<?php echo e($k+1); ?>" name="get_horariosc<?php echo e($k+1); ?>" 
                                value="<?php echo e($dayss); ?>">
                                <input type="hidden" class="repeatBloqOneEdit<?php echo e($k+1); ?>Time" name="get_horariosc<?php echo e($k+1); ?>_time" value="<?php echo e($complete->entry); ?>,<?php echo e($complete->exit); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $midday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $mid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $dayss = '';
                                    foreach($mid->days as $ke => $day){
                                       $dayss .= $daysShow[$day->day]; 
                                       if($ke < ($mid->days->count()-1)) {
                                        $dayss .= ',';
                                       }
                                    }                                    
                                ?>
                                <input type="hidden" class="repeatBloqOneEdit<?php echo e($k+1); ?>Medio" name="get_horarios_medioc<?php echo e($k+1); ?>" 
                                value="<?php echo e($dayss); ?>">
                                <input type="hidden" class="repeatBloqOneEdit<?php echo e($k+1); ?>TimeMedio" name="get_horariosc<?php echo e($k+1); ?>_time_medio" value="<?php echo e($mid->entry); ?>,<?php echo e($mid->exit); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 submitEditU">
                        <input type="submit" value="Aceptar">
                    </div>
                
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </section>


    <!-- Modal -->
    <?php echo $__env->make('front-end.partials.field-public-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript" ></script>
<script src="<?php echo e(asset('assets/js/clock/bootstrap-clockpicker.min.js')); ?>" type="text/javascript" ></script>
<script type="text/javascript">
    $('.clockpicker').clockpicker()
        .find('input').change(function() {
        console.log(this.value);
    });
    var input = $('#single-input').clockpicker({
        placement: 'bottom',
        align: 'left',
        autoclose: true,
        'default': 'now'
    });
    if (/mobile/i.test(navigator.userAgent)) {
        $('input').prop('readOnly', true);
    }
</script>
<script src="<?php echo e(asset('assets/js/admin/main_horarios.js')); ?>" type="text/javascript" ></script>
<script src="<?php echo e(asset('assets/js/admin/main_horarios_edit.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
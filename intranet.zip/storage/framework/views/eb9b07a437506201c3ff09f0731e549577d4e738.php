<?php $__env->startSection('content'); ?>
    <div class="container continerWithSite">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 sectionAdminContain">
            <div class="col-xs-12 col-sm-12 col-md-1 col-lg-1">

            </div>
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 sectionCenterContenido secCetTitleS">
                <h1>Calendario</h1>
                <?php echo $__env->make('back-end.partials.fields-name-admin-login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <form action="search_solicitudes_suegerencias" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 formSearch" method="post" accept-charset="utf-8">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <input type="text" name="user_search" placeholder="Buscar solicitud por nombre de usuario">
                    </div>
                </form>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <ul class="nav navbar-nav navbar-right navulRIght">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e(url('/logout')); ?>"
                               onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
                                Salir
                            </a>
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>


    <!-- content calendario -->
    <?php echo $__env->make('back-end.partials.fields-calendar-general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Modal -->
    <?php echo $__env->make('front-end.partials.field-public-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Modal NOTIFICACIONES -->
    <?php echo $__env->make('back-end.partials.fields-modal-notificaciones', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="alert alert-info dataClMoPosPEr" role="alert">¡Publicacion Agregada!</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Template-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="captionUsersInLive">
    <div class="ui accordion">
        <h3 class="fontMiriamProRegular"><span class="estusLive">•</span>En Linea</h3>
        <div class="title col-xs-12 col-sm-12 col-md-12 col-lg-12 AlluserReegitrados columnChatss captionLikechatsFlotante captionLikechatsFlotanteDta">
            <div class="captionCircleUser captionDenoews AlluserReegitradosPorBloque">
                <a href="#!" class="userLive" data-idonline="2" data-iduserchat="2">
                    <input type="hidden" name="_token" value="lEgRWkCkDrNuMQ36ujN6a1wK301wPsvf84onT1ZJ">
                    <div class="label dataPrubeIm vloqImageUser dataProfileAllUsersOnline" style="background-image: url('<?php echo e(asset('assets/profiles/49907.png')); ?>')">
                    </div>
                </a>
            </div>
            <div class="captionCircleUser captionDenoews AlluserReegitradosPorBloque">
                <a href="#!" class="userLive" data-idonline="2" data-iduserchat="2">
                    <input type="hidden" name="_token" value="lEgRWkCkDrNuMQ36ujN6a1wK301wPsvf84onT1ZJ">
                    <div class="label dataPrubeIm vloqImageUser dataProfileAllUsersOnline" style="background-image: url('<?php echo e(asset('assets/profiles/98196.jpg')); ?>')">
                    </div>
                </a>
            </div>
        </div>
        <div class="content col-xs-12 col-sm-12 col-md-12 col-lg-12 AlluserReegitrados columnChatss captionLikechatsFlotante captionLikechatsFlotanteDta">
            <div class="captionCircleUser captionDenoews AlluserReegitradosPorBloque">
                <a href="#!" class="userLive" data-idonline="2" data-iduserchat="2">
                    <input type="hidden" name="_token" value="lEgRWkCkDrNuMQ36ujN6a1wK301wPsvf84onT1ZJ">
                </a>
            </div>
        </div>
    </div>
</div>